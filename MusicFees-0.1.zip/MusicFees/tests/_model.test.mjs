// tests/model.test.ts
import * as at2 from "@coderline/alphatab";

// src/score/model.ts
import * as at from "@coderline/alphatab";

// src/score/instruments.ts
var TUNINGS = {
  std: { name: "Est\xE1ndar (E A D G B E)", strings: [64, 59, 55, 50, 45, 40] },
  dropD: { name: "Drop D", strings: [64, 59, 55, 50, 45, 38] },
  halfDown: { name: "Medio tono abajo (Eb)", strings: [63, 58, 54, 49, 44, 39] },
  dStd: { name: "Re est\xE1ndar (D)", strings: [62, 57, 53, 48, 43, 38] },
  dropC: { name: "Drop C", strings: [62, 57, 53, 48, 43, 36] },
  dadgad: { name: "DADGAD", strings: [62, 57, 55, 50, 45, 38] },
  openG: { name: "Open G", strings: [62, 59, 55, 50, 43, 38] },
  openD: { name: "Open D", strings: [62, 57, 54, 50, 45, 38] },
  seven: { name: "7 cuerdas (B)", strings: [64, 59, 55, 50, 45, 40, 35] },
  bass4: { name: "Bajo 4 (E A D G)", strings: [43, 38, 33, 28] },
  bass5: { name: "Bajo 5 (B E A D G)", strings: [43, 38, 33, 28, 23] },
  bassDropD: { name: "Bajo Drop D", strings: [43, 38, 33, 26] },
  requinto: { name: "Requinto (A D G C E A)", strings: [69, 64, 60, 55, 50, 45] },
  bajoSexto: { name: "Bajo sexto (E A D G C F)", strings: [65, 60, 55, 50, 45, 40] },
  vihuela: { name: "Vihuela (A D G B E)", strings: [64, 59, 67, 62, 57] },
  guitarron: { name: "Guitarr\xF3n (A D G C E A)", strings: [57, 52, 48, 43, 38, 33] },
  ukulele: { name: "Ukulele (G C E A)", strings: [69, 64, 60, 67] },
  mandolin: { name: "Mandolina (G D A E)", strings: [76, 69, 62, 55] },
  banjo: { name: "Banjo (gDGBD)", strings: [62, 59, 55, 50, 67] }
};
var DRUM_PIECES = [
  { id: 49, name: "Crash", short: "Cr" },
  { id: 57, name: "Crash 2", short: "Cr2" },
  { id: 55, name: "Splash", short: "Spl" },
  { id: 52, name: "China", short: "Ch" },
  { id: 51, name: "Ride", short: "Rd" },
  { id: 53, name: "Campana del ride", short: "Bell" },
  { id: 46, name: "Hi-hat abierto", short: "HHa" },
  { id: 42, name: "Hi-hat cerrado", short: "HHc" },
  { id: 44, name: "Hi-hat pedal", short: "HHp" },
  { id: 50, name: "Tom muy agudo", short: "T1" },
  { id: 48, name: "Tom agudo", short: "T2" },
  { id: 47, name: "Tom medio", short: "T3" },
  { id: 45, name: "Tom grave", short: "T4" },
  { id: 43, name: "Tom de piso", short: "TP" },
  { id: 38, name: "Caja", short: "Cj" },
  { id: 37, name: "Aro (side stick)", short: "Aro" },
  { id: 39, name: "Palmas", short: "Pal" },
  { id: 36, name: "Bombo", short: "Bo" },
  { id: 35, name: "Bombo ac\xFAstico", short: "Bo2" },
  { id: 54, name: "Pandero", short: "Pan" },
  { id: 56, name: "Cencerro", short: "Cen" }
];
var LATIN_PIECES = [
  { id: 65, name: "Timbal alto", short: "TbA" },
  { id: 66, name: "Timbal bajo", short: "TbB" },
  { id: 56, name: "Cencerro", short: "Cen" },
  { id: 60, name: "Bong\xF3 agudo", short: "BgA" },
  { id: 61, name: "Bong\xF3 grave", short: "BgG" },
  { id: 62, name: "Conga apagada", short: "CgX" },
  { id: 63, name: "Conga abierta", short: "Cga" },
  { id: 64, name: "Tumbadora", short: "Tum" },
  { id: 73, name: "G\xFCiro corto", short: "G\xFC" },
  { id: 74, name: "G\xFCiro largo", short: "G\xFC2" },
  { id: 70, name: "Maracas", short: "Mar" },
  { id: 75, name: "Claves", short: "Cla" },
  { id: 69, name: "Cabasa", short: "Cab" },
  { id: 82, name: "Shaker", short: "Shk" },
  { id: 85, name: "Casta\xF1uelas", short: "Cas" },
  { id: 54, name: "Pandero", short: "Pan" },
  { id: 81, name: "Tri\xE1ngulo", short: "Tri" }
];
var KIT = DRUM_PIECES.map((p) => p.id);
var LATIN = LATIN_PIECES.map((p) => p.id);
var T = TUNINGS;
var PRESETS = [
  // Guitarras y cuerdas pulsadas
  { id: "gtr_nylon", name: "Guitarra de nylon", group: "Guitarras", kind: "tab", program: 24, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_steel", name: "Guitarra ac\xFAstica", group: "Guitarras", kind: "tab", program: 25, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_jazz", name: "Guitarra de jazz", group: "Guitarras", kind: "tab", program: 26, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_clean", name: "El\xE9ctrica limpia", group: "Guitarras", kind: "tab", program: 27, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_muted", name: "El\xE9ctrica apagada (funk)", group: "Guitarras", kind: "tab", program: 28, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_od", name: "El\xE9ctrica con overdrive", group: "Guitarras", kind: "tab", program: 29, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_dist", name: "El\xE9ctrica distorsionada", group: "Guitarras", kind: "tab", program: 30, tuning: T.std.strings, notation: true, transpose: 12 },
  { id: "gtr_7", name: "Guitarra 7 cuerdas", group: "Guitarras", kind: "tab", program: 30, tuning: T.seven.strings, notation: true, transpose: 12 },
  { id: "requinto", name: "Requinto", group: "Guitarras", kind: "tab", program: 24, tuning: T.requinto.strings, notation: true, transpose: 12 },
  { id: "bajo_sexto", name: "Bajo sexto", group: "Guitarras", kind: "tab", program: 25, tuning: T.bajoSexto.strings, notation: true, transpose: 12 },
  { id: "vihuela", name: "Vihuela", group: "Guitarras", kind: "tab", program: 24, tuning: T.vihuela.strings, notation: true, transpose: 12 },
  { id: "ukulele", name: "Ukulele", group: "Guitarras", kind: "tab", program: 24, tuning: T.ukulele.strings, notation: true },
  { id: "mandolin", name: "Mandolina", group: "Guitarras", kind: "tab", program: 25, tuning: T.mandolin.strings, notation: true },
  { id: "banjo", name: "Banjo", group: "Guitarras", kind: "tab", program: 105, tuning: T.banjo.strings, notation: true, transpose: 12 },
  // Bajos
  { id: "bass_finger", name: "Bajo el\xE9ctrico (dedos)", group: "Bajos", kind: "tab", program: 33, tuning: T.bass4.strings, notation: true, transpose: 12 },
  { id: "bass_pick", name: "Bajo con p\xFAa", group: "Bajos", kind: "tab", program: 34, tuning: T.bass4.strings, notation: true, transpose: 12 },
  { id: "bass_slap", name: "Bajo slap", group: "Bajos", kind: "tab", program: 36, tuning: T.bass4.strings, notation: true, transpose: 12 },
  { id: "bass_fretless", name: "Bajo sin trastes", group: "Bajos", kind: "tab", program: 35, tuning: T.bass4.strings, notation: true, transpose: 12 },
  { id: "bass_5", name: "Bajo 5 cuerdas", group: "Bajos", kind: "tab", program: 33, tuning: T.bass5.strings, notation: true, transpose: 12 },
  { id: "tololoche", name: "Tololoche / contrabajo", group: "Bajos", kind: "tab", program: 32, tuning: T.bass4.strings, notation: true, transpose: 12 },
  { id: "guitarron", name: "Guitarr\xF3n", group: "Bajos", kind: "tab", program: 32, tuning: T.guitarron.strings, notation: true, transpose: 12 },
  { id: "synbass", name: "Bajo de sintetizador", group: "Bajos", kind: "notation", program: 38, clef: "F" },
  { id: "synbass2", name: "Bajo sinte (808/sub)", group: "Bajos", kind: "notation", program: 39, clef: "F" },
  // Teclados
  { id: "piano", name: "Piano", group: "Teclados", kind: "notation", program: 0, clef: "G" },
  { id: "piano_bright", name: "Piano brillante", group: "Teclados", kind: "notation", program: 1, clef: "G" },
  { id: "rhodes", name: "Piano el\xE9ctrico (Rhodes)", group: "Teclados", kind: "notation", program: 4, clef: "G" },
  { id: "dx7", name: "Piano FM (DX7, 80s)", group: "Teclados", kind: "notation", program: 5, clef: "G" },
  { id: "clavinet", name: "Clavinet", group: "Teclados", kind: "notation", program: 7, clef: "G" },
  { id: "harpsichord", name: "Clavec\xEDn (barroco)", group: "Teclados", kind: "notation", program: 6, clef: "G" },
  { id: "organ", name: "\xD3rgano Hammond", group: "Teclados", kind: "notation", program: 16, clef: "G" },
  { id: "organ_rock", name: "\xD3rgano de rock", group: "Teclados", kind: "notation", program: 18, clef: "G" },
  { id: "organ_church", name: "\xD3rgano de iglesia", group: "Teclados", kind: "notation", program: 19, clef: "G" },
  { id: "accordion", name: "Acorde\xF3n", group: "Teclados", kind: "notation", program: 21, clef: "G" },
  { id: "vibes", name: "Vibr\xE1fono", group: "Teclados", kind: "notation", program: 11, clef: "G" },
  { id: "marimba", name: "Marimba", group: "Teclados", kind: "notation", program: 12, clef: "G" },
  // Cuerdas y voces
  { id: "violin", name: "Viol\xEDn", group: "Cuerdas y voces", kind: "notation", program: 40, clef: "G" },
  { id: "viola", name: "Viola", group: "Cuerdas y voces", kind: "notation", program: 41, clef: "G" },
  { id: "cello", name: "Chelo", group: "Cuerdas y voces", kind: "notation", program: 42, clef: "F" },
  { id: "strings", name: "Ensamble de cuerdas", group: "Cuerdas y voces", kind: "notation", program: 48, clef: "G" },
  { id: "strings_slow", name: "Cuerdas lentas", group: "Cuerdas y voces", kind: "notation", program: 49, clef: "G" },
  { id: "pizz", name: "Cuerdas pizzicato", group: "Cuerdas y voces", kind: "notation", program: 45, clef: "G" },
  { id: "harp", name: "Arpa", group: "Cuerdas y voces", kind: "notation", program: 46, clef: "G" },
  { id: "choir", name: "Coro (aahs)", group: "Cuerdas y voces", kind: "notation", program: 52, clef: "G" },
  { id: "voice", name: "Voz (oohs)", group: "Cuerdas y voces", kind: "notation", program: 53, clef: "G" },
  // Vientos
  { id: "trumpet", name: "Trompeta", group: "Vientos", kind: "notation", program: 56, clef: "G" },
  { id: "trumpet_mute", name: "Trompeta con sordina", group: "Vientos", kind: "notation", program: 59, clef: "G" },
  { id: "trombone", name: "Tromb\xF3n", group: "Vientos", kind: "notation", program: 57, clef: "F" },
  { id: "tuba", name: "Tuba / charcheta", group: "Vientos", kind: "notation", program: 58, clef: "F" },
  { id: "horn", name: "Corno franc\xE9s", group: "Vientos", kind: "notation", program: 60, clef: "G" },
  { id: "brass", name: "Secci\xF3n de metales", group: "Vientos", kind: "notation", program: 61, clef: "G" },
  { id: "sax_alto", name: "Saxof\xF3n alto", group: "Vientos", kind: "notation", program: 65, clef: "G" },
  { id: "sax_tenor", name: "Saxof\xF3n tenor", group: "Vientos", kind: "notation", program: 66, clef: "G" },
  { id: "sax_bari", name: "Saxof\xF3n bar\xEDtono", group: "Vientos", kind: "notation", program: 67, clef: "F" },
  { id: "clarinet", name: "Clarinete", group: "Vientos", kind: "notation", program: 71, clef: "G" },
  { id: "flute", name: "Flauta", group: "Vientos", kind: "notation", program: 73, clef: "G" },
  { id: "panflute", name: "Flauta de pan", group: "Vientos", kind: "notation", program: 75, clef: "G" },
  { id: "harmonica", name: "Arm\xF3nica", group: "Vientos", kind: "notation", program: 22, clef: "G" },
  // Sintetizadores
  { id: "lead_square", name: "Lead cuadrado", group: "Sintetizadores", kind: "notation", program: 80, clef: "G" },
  { id: "lead_saw", name: "Lead sierra", group: "Sintetizadores", kind: "notation", program: 81, clef: "G" },
  { id: "pad_warm", name: "Pad c\xE1lido", group: "Sintetizadores", kind: "notation", program: 89, clef: "G" },
  { id: "pad_poly", name: "Polysynth (80s)", group: "Sintetizadores", kind: "notation", program: 90, clef: "G" },
  { id: "pad_halo", name: "Pad halo", group: "Sintetizadores", kind: "notation", program: 94, clef: "G" },
  { id: "pad_sweep", name: "Pad sweep", group: "Sintetizadores", kind: "notation", program: 95, clef: "G" },
  { id: "synth_brass", name: "Metales de sinte", group: "Sintetizadores", kind: "notation", program: 62, clef: "G" },
  { id: "synth_strings", name: "Cuerdas de sinte", group: "Sintetizadores", kind: "notation", program: 50, clef: "G" },
  { id: "orch_hit", name: "Orchestra hit (90s)", group: "Sintetizadores", kind: "notation", program: 55, clef: "G" },
  // Percusión (programa = kit GS en el canal 10)
  { id: "drums", name: "Bater\xEDa est\xE1ndar", group: "Percusi\xF3n", kind: "drums", program: 0, kit: KIT },
  { id: "drums_room", name: "Bater\xEDa de cuarto", group: "Percusi\xF3n", kind: "drums", program: 8, kit: KIT },
  { id: "drums_power", name: "Bater\xEDa power (rock)", group: "Percusi\xF3n", kind: "drums", program: 16, kit: KIT },
  { id: "drums_jazz", name: "Bater\xEDa de jazz", group: "Percusi\xF3n", kind: "drums", program: 32, kit: KIT },
  { id: "drums_brush", name: "Bater\xEDa con escobillas", group: "Percusi\xF3n", kind: "drums", program: 40, kit: KIT },
  { id: "drums_electronic", name: "Bater\xEDa electr\xF3nica", group: "Percusi\xF3n", kind: "drums", program: 24, kit: KIT },
  { id: "drums_808", name: "TR-808", group: "Percusi\xF3n", kind: "drums", program: 25, kit: KIT },
  { id: "latin", name: "Percusi\xF3n latina", group: "Percusi\xF3n", kind: "drums", program: 0, kit: LATIN }
];
var presetById = (id) => PRESETS.find((p) => p.id === id);
var STYLES = [
  { id: "blank_gtr", name: "Hoja en blanco (guitarra)", era: "", tempo: 100, tracks: [{ preset: "gtr_clean", name: "Guitarra" }] },
  { id: "classic_rock", name: "Classic rock", era: "60s\u201370s", tempo: 120, tracks: [{ preset: "gtr_od", name: "Guitarra" }, { preset: "bass_pick", name: "Bajo" }, { preset: "organ_rock", name: "\xD3rgano" }, { preset: "drums_room", name: "Bater\xEDa" }] },
  { id: "hard_rock", name: "Hard rock", era: "70s\u201380s", tempo: 132, tracks: [{ preset: "gtr_dist", name: "Guitarra r\xEDtmica" }, { preset: "gtr_dist", name: "Guitarra l\xEDder" }, { preset: "bass_pick", name: "Bajo" }, { preset: "drums_power", name: "Bater\xEDa" }] },
  { id: "post_punk", name: "Post punk", era: "late 70s\u201380s", tempo: 140, tracks: [{ preset: "gtr_clean", name: "Guitarra" }, { preset: "bass_pick", name: "Bajo" }, { preset: "pad_poly", name: "Sinte" }, { preset: "drums_room", name: "Bater\xEDa" }] },
  { id: "grunge", name: "Grunge", era: "90s", tempo: 116, tracks: [{ preset: "gtr_dist", name: "Guitarra", tuning: "dropD" }, { preset: "bass_pick", name: "Bajo", tuning: "bassDropD" }, { preset: "drums_power", name: "Bater\xEDa" }] },
  { id: "shoegaze", name: "Shoegaze", era: "90s", tempo: 110, tracks: [{ preset: "gtr_dist", name: "Guitarra muro" }, { preset: "gtr_clean", name: "Guitarra limpia" }, { preset: "bass_finger", name: "Bajo" }, { preset: "pad_halo", name: "Pad" }, { preset: "drums", name: "Bater\xEDa" }] },
  { id: "indie", name: "Indie rock", era: "2000s", tempo: 124, tracks: [{ preset: "gtr_clean", name: "Guitarra 1" }, { preset: "gtr_od", name: "Guitarra 2" }, { preset: "bass_pick", name: "Bajo" }, { preset: "drums", name: "Bater\xEDa" }] },
  { id: "math_rock", name: "Math rock", era: "2000s\u2013hoy", tempo: 150, tracks: [{ preset: "gtr_clean", name: "Guitarra tapping" }, { preset: "gtr_clean", name: "Guitarra 2" }, { preset: "bass_finger", name: "Bajo" }, { preset: "drums", name: "Bater\xEDa" }] },
  { id: "jazz", name: "Jazz tr\xEDo", era: "50s\u201360s", tempo: 140, tracks: [{ preset: "piano", name: "Piano" }, { preset: "tololoche", name: "Contrabajo" }, { preset: "drums_brush", name: "Bater\xEDa" }, { preset: "gtr_jazz", name: "Guitarra" }] },
  { id: "bossa", name: "Bossa nova", era: "60s", tempo: 128, tracks: [{ preset: "gtr_nylon", name: "Viol\xE3o" }, { preset: "bass_finger", name: "Bajo" }, { preset: "rhodes", name: "Rhodes" }, { preset: "flute", name: "Flauta" }, { preset: "drums_brush", name: "Bater\xEDa" }] },
  { id: "funk", name: "Funk", era: "70s", tempo: 104, tracks: [{ preset: "gtr_muted", name: "Guitarra" }, { preset: "bass_slap", name: "Bajo slap" }, { preset: "clavinet", name: "Clavinet" }, { preset: "brass", name: "Metales" }, { preset: "drums", name: "Bater\xEDa" }] },
  { id: "disco", name: "Disco", era: "70s", tempo: 120, tracks: [{ preset: "gtr_muted", name: "Guitarra" }, { preset: "bass_finger", name: "Bajo" }, { preset: "strings", name: "Cuerdas" }, { preset: "piano_bright", name: "Piano" }, { preset: "drums", name: "Bater\xEDa" }] },
  { id: "eighties_pop", name: "Pop 80s", era: "80s", tempo: 118, tracks: [{ preset: "dx7", name: "Piano FM" }, { preset: "pad_poly", name: "Polysynth" }, { preset: "synbass", name: "Bajo sinte" }, { preset: "gtr_clean", name: "Guitarra" }, { preset: "drums_electronic", name: "Bater\xEDa" }] },
  { id: "pop", name: "Pop actual", era: "hoy", tempo: 100, tracks: [{ preset: "piano", name: "Piano" }, { preset: "gtr_steel", name: "Guitarra" }, { preset: "synbass2", name: "Bajo" }, { preset: "pad_warm", name: "Pad" }, { preset: "drums_electronic", name: "Bater\xEDa" }] },
  { id: "house", name: "House / dance", era: "90s\u2013hoy", tempo: 124, tracks: [{ preset: "synbass2", name: "Bajo" }, { preset: "rhodes", name: "Acordes" }, { preset: "lead_saw", name: "Lead" }, { preset: "drums_808", name: "Bater\xEDa 808" }] },
  { id: "techno", name: "Techno / electro", era: "90s\u2013hoy", tempo: 132, tracks: [{ preset: "synbass", name: "Bajo" }, { preset: "lead_square", name: "Secuencia" }, { preset: "pad_sweep", name: "Pad" }, { preset: "drums_808", name: "Bater\xEDa 808" }] },
  { id: "hiphop", name: "Hip hop", era: "90s\u2013hoy", tempo: 90, tracks: [{ preset: "rhodes", name: "Rhodes" }, { preset: "synbass2", name: "Bajo 808" }, { preset: "strings", name: "Cuerdas" }, { preset: "drums_808", name: "Bater\xEDa" }] },
  { id: "bolero", name: "Bolero", era: "40s\u201360s", tempo: 76, tracks: [{ preset: "requinto", name: "Requinto" }, { preset: "gtr_nylon", name: "Guitarra" }, { preset: "tololoche", name: "Contrabajo" }, { preset: "latin", name: "Percusi\xF3n" }] },
  { id: "corrido_clasico", name: "Corrido cl\xE1sico (norte\xF1o)", era: "70s\u201390s", tempo: 112, tracks: [{ preset: "accordion", name: "Acorde\xF3n" }, { preset: "bajo_sexto", name: "Bajo sexto" }, { preset: "bass_finger", name: "Bajo" }, { preset: "drums", name: "Bater\xEDa" }] },
  { id: "corrido_moderno", name: "Corrido moderno (tumbado)", era: "hoy", tempo: 100, tracks: [{ preset: "requinto", name: "Requinto" }, { preset: "gtr_steel", name: "Guitarra" }, { preset: "tuba", name: "Charcheta" }, { preset: "tololoche", name: "Tololoche" }] },
  { id: "mariachi", name: "Mariachi", era: "cl\xE1sico", tempo: 120, tracks: [{ preset: "trumpet", name: "Trompeta 1" }, { preset: "trumpet", name: "Trompeta 2" }, { preset: "violin", name: "Violines" }, { preset: "vihuela", name: "Vihuela" }, { preset: "gtr_nylon", name: "Guitarra" }, { preset: "guitarron", name: "Guitarr\xF3n" }] },
  { id: "oldies", name: "Oldies / doo-wop", era: "50s\u201360s", tempo: 96, tracks: [{ preset: "piano", name: "Piano" }, { preset: "gtr_clean", name: "Guitarra" }, { preset: "bass_finger", name: "Bajo" }, { preset: "sax_tenor", name: "Saxof\xF3n" }, { preset: "voice", name: "Coros" }, { preset: "drums_room", name: "Bater\xEDa" }] },
  { id: "baroque", name: "Barroco", era: "1600\u20131750", tempo: 88, tracks: [{ preset: "harpsichord", name: "Clavec\xEDn" }, { preset: "violin", name: "Viol\xEDn" }, { preset: "cello", name: "Chelo" }] }
];
var styleById = (id) => STYLES.find((s) => s.id === id);

// src/score/model.ts
var M = at.model;
var settings = new at.Settings();
var NOTE_TEX = ["c", "c#", "d", "d#", "e", "f", "f#", "g", "g#", "a", "a#", "b"];
var texPitch = (m) => NOTE_TEX[m % 12] + (Math.floor(m / 12) - 1);
var esc = (s) => s.replace(/\\/g, "").replace(/"/g, "'");
function kindOf(track) {
  const st = track.staves[0];
  if (st.isPercussion) return "drums";
  if (st.isStringed && st.tuning.length > 0) return "tab";
  return "notation";
}
var rowToString = (track, row) => track.staves[0].tuning.length - row;
function beatAt(score, r) {
  const tr = score.tracks[r.t];
  const bar = tr?.staves[0]?.bars[r.b];
  const voice = bar?.voices[r.v];
  return voice?.beats[r.i] ?? null;
}
function findNote(beat, k) {
  if (k.str != null) return beat.notes.find((n) => n.string === k.str) ?? null;
  if (k.art != null) return beat.notes.find((n) => n.percussionArticulation === k.art) ?? null;
  if (k.pitch != null) return beat.notes.find((n) => n.realValue === k.pitch) ?? null;
  return null;
}
function newRestBeat(dur, dots = 0) {
  const b = new M.Beat();
  b.duration = dur;
  b.dots = dots;
  b.isEmpty = false;
  return b;
}
function relinkBeats(voice) {
  const beats = voice.beats.slice();
  voice.beats.length = 0;
  for (const b of beats) {
    b.previousBeat = null;
    b.nextBeat = null;
    voice.addBeat(b);
  }
}
function setPitchOnNote(n, midi2) {
  n.octave = Math.floor(midi2 / 12) - 1;
  n.tone = midi2 % 12;
}
function trackTex(p, name, tuning, bars) {
  const rest = Array.from({ length: bars }, () => "r.1").join(" | ");
  if (p.kind === "drums") {
    const chord = `(${(p.kit ?? [38, 36, 42]).join(" ")}).1`;
    const restB = bars > 1 ? " | " + Array.from({ length: bars - 1 }, () => "r.1").join(" | ") : "";
    return `\\track "${esc(name)}" \\staff {score} \\instrument percussion \\articulation defaults ${chord}${restB} |`;
  }
  if (p.kind === "tab") {
    const tun = (tuning ?? p.tuning ?? TUNINGS.std.strings).map(texPitch).join(" ");
    return `\\track "${esc(name)}" \\staff {${p.notation ? "score tabs" : "tabs"}} \\tuning ${tun} \\instrument ${p.program} ${rest} |`;
  }
  return `\\track "${esc(name)}" \\staff {score} \\instrument ${p.program} ${rest} |`;
}
function finishTrack(track, p) {
  const st = track.staves[0];
  track.playbackInfo.program = p.program;
  if (p.kind === "drums") {
    const beat = st.bars[0].voices[0].beats[0];
    for (const n of beat.notes.slice()) beat.removeNote(n);
  }
  if (p.kind === "notation" && p.clef === "F") for (const bar of st.bars) bar.clef = M.Clef.F4;
  if (p.transpose) st.displayTranspositionPitch = -p.transpose;
  track.__preset = p.id;
}
function createSong(styleId = "blank_gtr", bars = 8, title = "Sin t\xEDtulo") {
  const style = styleById(styleId) ?? styleById("blank_gtr");
  let tex = `\\title "${esc(title)}" \\tempo ${style.tempo} `;
  const ps = [];
  for (const t of style.tracks) {
    const p = presetById(t.preset);
    ps.push(p);
    tex += trackTex(p, t.name, t.tuning ? TUNINGS[t.tuning].strings : void 0, bars) + " ";
  }
  const score = at.importer.ScoreLoader.loadAlphaTex(tex, settings);
  score.tracks.forEach((tr, i) => finishTrack(tr, ps[i]));
  assignChannels(score);
  finishScore(score);
  return score;
}
function assignChannels(score) {
  let ch = 0;
  for (const tr of score.tracks) {
    if (tr.staves[0].isPercussion) {
      tr.playbackInfo.primaryChannel = 9;
      tr.playbackInfo.secondaryChannel = 9;
      continue;
    }
    if (ch === 9) ch++;
    tr.playbackInfo.primaryChannel = ch % 16;
    ch++;
    if (ch === 9) ch++;
    tr.playbackInfo.secondaryChannel = ch % 16;
    ch++;
  }
}
function addTrack(score, presetId, name, tuning) {
  const p = presetById(presetId) ?? PRESETS[0];
  const bars = score.masterBars.length;
  const tex = `\\title "x" ` + trackTex(p, name ?? p.name, tuning, bars);
  const tmp = at.importer.ScoreLoader.loadAlphaTex(tex, settings);
  const tr = tmp.tracks[0];
  finishTrack(tr, p);
  tr.score = score;
  score.addTrack(tr);
  assignChannels(score);
}
function rebuildBars(score, masterBars, perStaff) {
  score.masterBars.length = 0;
  for (const mb of masterBars) {
    mb.previousMasterBar = null;
    mb.nextMasterBar = null;
    score.addMasterBar(mb);
  }
  for (const [staff, bars] of perStaff) {
    staff.bars.length = 0;
    for (const b of bars) {
      b.previousBar = null;
      b.nextBar = null;
      staff.addBar(b);
    }
  }
}
function insertBar(score, atIndex) {
  const idx = Math.max(0, Math.min(atIndex, score.masterBars.length));
  const ref = score.masterBars[Math.max(0, idx - 1)];
  const mb = new M.MasterBar();
  if (ref) {
    mb.timeSignatureNumerator = ref.timeSignatureNumerator;
    mb.timeSignatureDenominator = ref.timeSignatureDenominator;
    mb.tripletFeel = ref.tripletFeel;
  }
  const mbs = score.masterBars.slice();
  mbs.splice(idx, 0, mb);
  const per = /* @__PURE__ */ new Map();
  for (const tr of score.tracks)
    for (const st of tr.staves) {
      const prev = st.bars[Math.max(0, idx - 1)];
      const bar = new M.Bar();
      if (prev) {
        bar.clef = prev.clef;
        bar.keySignature = prev.keySignature;
        bar.keySignatureType = prev.keySignatureType;
      }
      const v = new M.Voice();
      bar.addVoice(v);
      v.addBeat(newRestBeat(M.Duration.Whole));
      const list = st.bars.slice();
      list.splice(idx, 0, bar);
      per.set(st, list);
    }
  rebuildBars(score, mbs, per);
}
function deleteBar(score, atIndex) {
  if (score.masterBars.length <= 1 || atIndex < 0 || atIndex >= score.masterBars.length) return;
  const mbs = score.masterBars.slice();
  const removed = mbs.splice(atIndex, 1)[0];
  if (atIndex === 0 && removed.tempoAutomations.length && mbs[0] && !mbs[0].tempoAutomations.length)
    mbs[0].tempoAutomations.push(...removed.tempoAutomations);
  const per = /* @__PURE__ */ new Map();
  for (const tr of score.tracks)
    for (const st of tr.staves) {
      const list = st.bars.slice();
      list.splice(atIndex, 1);
      per.set(st, list);
    }
  rebuildBars(score, mbs, per);
}
function setTempo(score, b, bpm) {
  const mb = score.masterBars[b];
  if (!mb) return;
  mb.tempoAutomations = mb.tempoAutomations.filter((a2) => a2.type !== M.AutomationType.Tempo);
  const a = M.Automation.buildTempoAutomation(false, 0, bpm, 2);
  mb.tempoAutomations.push(a);
}
var DYN = [M.DynamicValue.PPP, M.DynamicValue.PP, M.DynamicValue.P, M.DynamicValue.MP, M.DynamicValue.MF, M.DynamicValue.F, M.DynamicValue.FF, M.DynamicValue.FFF];
var dynValue = (i) => DYN[Math.max(0, Math.min(7, i))];
function applyNoteFx(n, fx, on) {
  switch (fx) {
    case "hammer":
      n.isHammerPullOrigin = on;
      break;
    case "slide":
      n.slideOutType = on ? M.SlideOutType.Legato : M.SlideOutType.None;
      break;
    case "bend":
      n.bendPoints = null;
      n.bendType = M.BendType.None;
      if (on) {
        n.bendType = M.BendType.Bend;
        n.addBendPoint(new M.BendPoint(0, 0));
        n.addBendPoint(new M.BendPoint(15, 4));
        n.addBendPoint(new M.BendPoint(60, 4));
      }
      break;
    case "vibrato":
      n.vibrato = on ? M.VibratoType.Slight : M.VibratoType.None;
      break;
    case "palmMute":
      n.isPalmMute = on;
      break;
    case "letRing":
      n.isLetRing = on;
      break;
    case "dead":
      n.isDead = on;
      break;
    case "ghost":
      n.isGhost = on;
      break;
    case "accent":
      n.accentuated = on ? M.AccentuationType.Normal : M.AccentuationType.None;
      break;
    case "heavyAccent":
      n.accentuated = on ? M.AccentuationType.Heavy : M.AccentuationType.None;
      break;
    case "harmonic":
      n.harmonicType = on ? M.HarmonicType.Natural : M.HarmonicType.None;
      n.harmonicValue = on ? 12 : 0;
      break;
    case "staccato":
      n.isStaccato = on;
      break;
    case "tie":
      n.isTieDestination = on;
      break;
  }
}
function applyOp(score, op) {
  switch (op.k) {
    case "load":
      return at.model.JsonConverter.jsonToScore(op.json, settings);
    case "fret": {
      const beat = beatAt(score, op);
      if (!beat) break;
      let n = beat.notes.find((x) => x.string === op.str);
      if (!n) {
        n = new M.Note();
        n.string = op.str;
        beat.addNote(n);
      }
      n.fret = Math.max(0, Math.min(36, op.fret));
      beat.isEmpty = false;
      break;
    }
    case "pitch": {
      const beat = beatAt(score, op);
      if (!beat) break;
      const ex = beat.notes.find((x) => x.realValue === op.pitch);
      if (op.on && !ex) {
        const n = new M.Note();
        setPitchOnNote(n, op.pitch);
        beat.addNote(n);
        beat.isEmpty = false;
      } else if (!op.on && ex) beat.removeNote(ex);
      break;
    }
    case "perc": {
      const beat = beatAt(score, op);
      if (!beat) break;
      const ex = beat.notes.find((x) => x.percussionArticulation === op.art);
      if (op.on && !ex) {
        const n = new M.Note();
        n.percussionArticulation = op.art;
        beat.addNote(n);
        beat.isEmpty = false;
      } else if (!op.on && ex) beat.removeNote(ex);
      break;
    }
    case "delNote": {
      const beat = beatAt(score, op);
      const n = beat && findNote(beat, op);
      if (beat && n) beat.removeNote(n);
      break;
    }
    case "clear": {
      const beat = beatAt(score, op);
      if (beat) for (const n of beat.notes.slice()) beat.removeNote(n);
      break;
    }
    case "insBeat": {
      const voice = score.tracks[op.t]?.staves[0]?.bars[op.b]?.voices[op.v];
      if (!voice) break;
      const nb = newRestBeat(op.dur, op.dots ?? 0);
      const list = voice.beats.slice();
      list.splice(op.after + 1, 0, nb);
      voice.beats.length = 0;
      for (const b of list) voice.beats.push(b);
      relinkBeats(voice);
      break;
    }
    case "delBeat": {
      const beat = beatAt(score, op);
      if (!beat) break;
      const voice = beat.voice;
      if (voice.beats.length <= 1) {
        for (const n of beat.notes.slice()) beat.removeNote(n);
        break;
      }
      voice.beats.splice(op.i, 1);
      relinkBeats(voice);
      break;
    }
    case "dur": {
      const b = beatAt(score, op);
      if (b) b.duration = op.dur;
      break;
    }
    case "dots": {
      const b = beatAt(score, op);
      if (b) b.dots = Math.max(0, Math.min(2, op.n));
      break;
    }
    case "tuplet": {
      const b = beatAt(score, op);
      if (!b) break;
      if (op.n <= 1) {
        b.tupletNumerator = -1;
        b.tupletDenominator = -1;
      } else {
        b.tupletNumerator = op.n;
        b.tupletDenominator = op.n === 3 ? 2 : op.n === 6 ? 4 : 4;
      }
      break;
    }
    case "noteFx": {
      const beat = beatAt(score, op);
      const n = beat && findNote(beat, op);
      if (n) applyNoteFx(n, op.fx, op.on);
      break;
    }
    case "beatFx": {
      const b = beatAt(score, op);
      if (!b) break;
      const v = op.val;
      switch (op.fx) {
        case "dynamics":
          b.dynamics = dynValue(Number(v));
          for (const n of b.notes) n.dynamics = b.dynamics;
          break;
        case "crescendo":
          b.crescendo = Number(v);
          break;
        case "tap":
          b.tap = !!v;
          break;
        case "slap":
          b.slap = !!v;
          break;
        case "pop":
          b.pop = !!v;
          break;
        case "text":
          b.text = v ? String(v) : null;
          break;
        case "chord":
          b.chordId = v ? String(v) : null;
          break;
        case "pickStroke":
          b.pickStroke = Number(v);
          break;
        case "fadeIn":
          b.fade = v ? M.FadeType.FadeIn : M.FadeType.None;
          break;
        case "brush":
          b.brushType = Number(v);
          break;
        case "vibratoBeat":
          b.vibrato = v ? M.VibratoType.Wide : M.VibratoType.None;
          break;
      }
      break;
    }
    case "dynFrom": {
      const start = beatAt(score, op);
      if (!start) break;
      const old = start.dynamics, nv = dynValue(op.val);
      const staff = start.voice.bar.staff;
      let on = false;
      outer: for (const bar of staff.bars) {
        if (bar.index < op.b) continue;
        const v = bar.voices[op.v];
        if (!v) continue;
        for (const b of v.beats) {
          if (bar.index === op.b && b.index < op.i) continue;
          if (on && b.dynamics !== old) break outer;
          on = true;
          b.dynamics = nv;
          for (const n of b.notes) n.dynamics = nv;
        }
      }
      break;
    }
    case "barIns":
      insertBar(score, op.at);
      break;
    case "barDel":
      deleteBar(score, op.at);
      break;
    case "barProp": {
      const mb = score.masterBars[op.b];
      if (!mb) break;
      const v = op.val;
      switch (op.prop) {
        case "ts": {
          const [n, d] = String(v).split("/").map(Number);
          if (n > 0 && [1, 2, 4, 8, 16, 32].includes(d)) {
            mb.timeSignatureNumerator = n;
            mb.timeSignatureDenominator = d;
          }
          break;
        }
        case "repeatOpen":
          mb.isRepeatStart = !!v;
          break;
        case "repeatClose":
          mb.repeatCount = Number(v) || 0;
          break;
        case "doubleBar":
          mb.isDoubleBar = !!v;
          break;
        case "alternate":
          mb.alternateEndings = Number(v) || 0;
          break;
        case "section": {
          if (!v) mb.section = null;
          else {
            const s = new M.Section();
            const [marker, ...rest] = String(v).split("|");
            s.marker = marker;
            s.text = rest.join("|") || marker;
            mb.section = s;
          }
          break;
        }
        case "tempo":
          setTempo(score, op.b, Number(v));
          break;
        case "key":
          for (const tr of score.tracks) for (const st of tr.staves) {
            const bar = st.bars[op.b];
            if (bar) bar.keySignature = Number(v);
          }
          break;
      }
      break;
    }
    case "trackAdd":
      addTrack(score, op.preset, op.name, op.tuning);
      break;
    case "trackDel": {
      if (score.tracks.length <= 1) break;
      score.tracks.splice(op.t, 1);
      score.tracks.forEach((t, i) => t.index = i);
      break;
    }
    case "trackMove": {
      const [tr] = score.tracks.splice(op.t, 1);
      if (!tr) break;
      score.tracks.splice(Math.max(0, Math.min(op.to, score.tracks.length)), 0, tr);
      score.tracks.forEach((t, i) => t.index = i);
      break;
    }
    case "trackProp": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      const st = tr.staves[0];
      const v = op.val;
      switch (op.prop) {
        case "name":
          tr.name = String(v).slice(0, 60);
          tr.shortName = tr.name.slice(0, 10);
          break;
        case "program":
          tr.playbackInfo.program = Number(v);
          break;
        case "tuning":
          if (Array.isArray(v) && v.length === st.tuning.length) st.stringTuning = new M.Tuning("", v.slice(), false);
          break;
        case "capo":
          st.capo = Math.max(0, Math.min(12, Number(v)));
          break;
        case "volume":
          tr.playbackInfo.volume = Math.max(0, Math.min(16, Number(v)));
          break;
        case "balance":
          tr.playbackInfo.balance = Math.max(0, Math.min(16, Number(v)));
          break;
        case "showTab":
          if (st.isStringed) st.showTablature = !!v;
          if (!st.showTablature && !st.showStandardNotation) st.showStandardNotation = true;
          break;
        case "showNotation":
          st.showStandardNotation = !!v;
          if (!st.showTablature && !st.showStandardNotation) st.showTablature = st.isStringed;
          break;
        case "color":
          break;
        case "mute":
          tr.playbackInfo.isMute = !!v;
          break;
        case "solo":
          tr.playbackInfo.isSolo = !!v;
          break;
      }
      break;
    }
    case "songProp": {
      const v = op.val;
      if (op.prop === "tempo") setTempo(score, 0, Number(v));
      else score[op.prop] = String(v).slice(0, 120);
      break;
    }
    case "chordDef": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      const st = tr.staves[0];
      const c = new M.Chord();
      c.name = op.name;
      c.strings = op.frets.slice();
      const played = op.frets.filter((f) => f > 0);
      c.firstFret = played.length ? Math.max(1, Math.min(...played)) : 1;
      if (Math.max(0, ...played) <= 4) c.firstFret = 1;
      c.showDiagram = true;
      c.showName = true;
      st.addChord(op.id, c);
      break;
    }
    case "voices": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      for (const bar of tr.staves[0].bars)
        while (bar.voices.length < Math.min(4, op.n)) {
          const v = new M.Voice();
          bar.addVoice(v);
          const b = new M.Beat();
          b.duration = M.Duration.Whole;
          b.isEmpty = true;
          v.addBeat(b);
        }
      break;
    }
    case "lyrics": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      for (const bar of tr.staves[0].bars) for (const v of bar.voices) for (const b of v.beats) b.lyrics = null;
      const l = new M.Lyrics();
      l.startBar = 0;
      l.text = op.text;
      l.finish();
      tr.applyLyrics([l]);
      tr.__lyrics = op.text;
      break;
    }
  }
  return score;
}
function renumberIds(score) {
  let bar = 0, voice = 0, beat = 0, note = 0;
  for (const tr of score.tracks)
    for (const st of tr.staves)
      for (const b of st.bars) {
        b.id = bar++;
        for (const v of b.voices) {
          v.id = voice++;
          for (const bt of v.beats) {
            bt.id = beat++;
            for (const n of bt.notes) n.id = note++;
          }
        }
      }
}
function finishScore(score) {
  renumberIds(score);
  score.finish(settings);
}
var toJson = (score) => at.model.JsonConverter.scoreToJson(score);
var fromJson = (json) => {
  const s = at.model.JsonConverter.jsonToScore(json, settings);
  return s;
};
function beatTicks(beat) {
  let t = 3840 / beat.duration;
  let add = t / 2;
  for (let i = 0; i < beat.dots; i++) {
    t += add;
    add /= 2;
  }
  if (beat.hasTuplet) t = t * beat.tupletDenominator / beat.tupletNumerator;
  return t;
}
function barCapacity(mb) {
  return 3840 / mb.timeSignatureDenominator * mb.timeSignatureNumerator;
}
function voiceUsed(voice) {
  return voice.beats.reduce((s, b) => s + beatTicks(b), 0);
}

// tests/model.test.ts
import assert from "node:assert/strict";
import { test } from "node:test";
test("todas las plantillas se crean y exportan a GP7", () => {
  for (const st of STYLES) {
    const s = createSong(st.id, 4, st.name);
    assert.equal(s.tracks.length, st.tracks.length, st.id);
    const gp = new at2.exporter.Gp7Exporter().export(s, settings);
    const back = at2.importer.ScoreLoader.loadScoreFromBytes(gp, settings);
    assert.equal(back.tracks.length, st.tracks.length);
  }
});
test("edici\xF3n de tablatura, efectos, din\xE1mica, compases y JSON", () => {
  let s = createSong("hard_rock", 4, "Prueba");
  const tr = s.tracks[0];
  assert.equal(kindOf(tr), "tab");
  const str = rowToString(tr, 5);
  applyOp(s, { k: "dur", t: 0, b: 0, v: 0, i: 0, dur: 8 });
  applyOp(s, { k: "fret", t: 0, b: 0, v: 0, i: 0, str, fret: 3 });
  applyOp(s, { k: "insBeat", t: 0, b: 0, v: 0, after: 0, dur: 8 });
  applyOp(s, { k: "fret", t: 0, b: 0, v: 0, i: 1, str, fret: 5 });
  applyOp(s, { k: "noteFx", t: 0, b: 0, v: 0, i: 0, str, fx: "hammer", on: true });
  applyOp(s, { k: "noteFx", t: 0, b: 0, v: 0, i: 1, str, fx: "bend", on: true });
  applyOp(s, { k: "beatFx", t: 0, b: 0, v: 0, i: 0, fx: "dynamics", val: 6 });
  applyOp(s, { k: "beatFx", t: 0, b: 0, v: 0, i: 1, fx: "crescendo", val: 1 });
  applyOp(s, { k: "barIns", at: 1 });
  applyOp(s, { k: "barProp", b: 1, prop: "ts", val: "3/4" });
  applyOp(s, { k: "barProp", b: 1, prop: "section", val: "A|Intro" });
  applyOp(s, { k: "barProp", b: 2, prop: "tempo", val: 140 });
  applyOp(s, { k: "trackAdd", preset: "piano" });
  applyOp(s, { k: "pitch", t: 4, b: 0, v: 0, i: 0, pitch: 60, on: true });
  applyOp(s, { k: "pitch", t: 4, b: 0, v: 0, i: 0, pitch: 64, on: true });
  applyOp(s, { k: "perc", t: 3, b: 0, v: 0, i: 0, art: 0, on: true });
  applyOp(s, { k: "chordDef", t: 0, id: "Em", name: "Em", frets: [0, 0, 0, 2, 2, 0] });
  applyOp(s, { k: "beatFx", t: 0, b: 0, v: 0, i: 0, fx: "chord", val: "Em" });
  applyOp(s, { k: "lyrics", t: 0, text: "ho- la mun- do" });
  finishScore(s);
  const b0 = s.tracks[0].staves[0].bars[0].voices[0].beats;
  assert.equal(b0[0].notes[0].realValue, 43);
  assert.equal(b0[1].notes[0].fret, 5);
  assert.ok(b0[0].notes[0].isHammerPullOrigin);
  assert.ok(b0[1].notes[0].hasBend);
  assert.equal(s.masterBars.length, 5, "mb");
  assert.equal(s.masterBars[1].timeSignatureNumerator, 3);
  assert.equal(s.tracks[4].staves[0].bars[0].voices[0].beats[0].notes.length, 2);
  assert.equal(s.tracks[4].staves[0].bars.length, 5, "pianobars");
  assert.equal(beatTicks(b0[0]), 480);
  assert.equal(barCapacity(s.masterBars[0]), 3840);
  assert.equal(voiceUsed(s.tracks[0].staves[0].bars[0].voices[0]), 960);
  const json = toJson(s);
  const s2 = fromJson(json);
  assert.equal(s2.tracks.length, 5);
  assert.equal(s2.tracks[0].staves[0].bars[0].voices[0].beats[1].notes[0].fret, 5);
  assert.equal(s2.masterBars[1].section?.text, "Intro");
  const gp = new at2.exporter.Gp7Exporter().export(s2, settings);
  const back = at2.importer.ScoreLoader.loadScoreFromBytes(gp, settings);
  assert.equal(back.masterBars.length, 5, "backmb");
  assert.equal(back.tracks[0].staves[0].bars[0].voices[0].beats[0].dynamics, at2.model.DynamicValue.FF);
  const mf = new at2.midi.MidiFile();
  new at2.midi.MidiFileGenerator(s2, settings, new at2.midi.AlphaSynthMidiFileHandler(mf, true)).generate();
  assert.ok(mf.toBinary().length > 100);
  applyOp(s, { k: "barDel", at: 1 });
  applyOp(s, { k: "delBeat", t: 0, b: 0, v: 0, i: 1 });
  applyOp(s, { k: "trackDel", t: 4 });
  finishScore(s);
  assert.equal(s.masterBars.length, 4);
  assert.equal(s.tracks.length, 4);
  console.log("json KB", (json.length / 1024).toFixed(1));
});
