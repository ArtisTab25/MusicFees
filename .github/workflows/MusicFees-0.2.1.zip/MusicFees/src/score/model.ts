// Modelo de la canción sobre alphaTab y operaciones de edición deterministas.
// Cada cambio es una operación serializable: se aplica local y se envía tal cual al dúo.
import * as at from "@coderline/alphatab";
import { PRESETS, presetById, styleById, TUNINGS, type Preset } from "./instruments";

type Score = at.model.Score;
type Track = at.model.Track;
type Beat = at.model.Beat;
type Note = at.model.Note;
const M = at.model;

export const settings = new at.Settings();

export type Kind = "tab" | "notation" | "drums";
export interface BeatRef { t: number; b: number; v: number; i: number }
export type NoteKey = { str?: number; pitch?: number; art?: number };

export type Op =
  | ({ k: "fret"; str: number; fret: number; len?: number } & BeatRef)
  | ({ k: "pitch"; pitch: number; on: boolean } & BeatRef)
  | ({ k: "perc"; art: number; on: boolean } & BeatRef)
  | ({ k: "delNote" } & BeatRef & NoteKey)
  | ({ k: "insBeat"; dur: number; dots?: number } & Omit<BeatRef, "i"> & { after: number })
  | ({ k: "delBeat" } & BeatRef)
  | ({ k: "clear" } & BeatRef)
  | ({ k: "dur"; dur: number } & BeatRef)
  | ({ k: "dots"; n: number } & BeatRef)
  | ({ k: "tuplet"; n: number } & BeatRef)
  | ({ k: "noteFx"; fx: NoteFx; on: boolean } & BeatRef & NoteKey)
  | ({ k: "beatFx"; fx: BeatFx; val: number | string | boolean | null } & BeatRef)
  | ({ k: "dynFrom"; val: number } & BeatRef)
  | { k: "barIns"; at: number }
  | { k: "barDel"; at: number }
  | { k: "barProp"; b: number; prop: BarProp; val: number | string | boolean | null }
  | { k: "trackAdd"; preset: string; name?: string; tuning?: number[] }
  | { k: "trackDel"; t: number }
  | { k: "trackMove"; t: number; to: number }
  | { k: "trackProp"; t: number; prop: TrackProp; val: unknown }
  | { k: "songProp"; prop: SongProp; val: string | number }
  | { k: "chordDef"; t: number; id: string; name: string; frets: number[] }
  | { k: "lyrics"; t: number; text: string }
  | { k: "voices"; t: number; n: number }
  | { k: "load"; json: string };

export type NoteFx = "hammer" | "slide" | "bend" | "vibrato" | "palmMute" | "letRing" | "dead" | "ghost" | "accent" | "heavyAccent" | "harmonic" | "staccato" | "tie";
export type BeatFx = "dynamics" | "crescendo" | "tap" | "slap" | "pop" | "text" | "chord" | "pickStroke" | "fadeIn" | "brush" | "vibratoBeat";
export type BarProp = "ts" | "repeatOpen" | "repeatClose" | "section" | "tempo" | "doubleBar" | "key" | "alternate";
export type TrackProp = "name" | "program" | "tuning" | "capo" | "volume" | "balance" | "showTab" | "showNotation" | "color" | "mute" | "solo";
export type SongProp = "title" | "artist" | "album" | "words" | "music" | "tempo";

// ---------- utilidades ----------
const NOTE_TEX = ["c", "c#", "d", "d#", "e", "f", "f#", "g", "g#", "a", "a#", "b"];
export const texPitch = (m: number) => NOTE_TEX[m % 12] + (Math.floor(m / 12) - 1);
const esc = (s: string) => s.replace(/\\/g, "").replace(/"/g, "'");

export function kindOf(track: Track): Kind {
  const st = track.staves[0];
  if (st.isPercussion) return "drums";
  if (st.isStringed && st.tuning.length > 0) return "tab";
  return "notation";
}
export const trackTuning = (track: Track) => track.staves[0].tuning.slice(); // aguda → grave
/** Fila visual (0 = cuerda más aguda) a número de cuerda de alphaTab (1 = la más grave). */
export const rowToString = (track: Track, row: number) => track.staves[0].tuning.length - row;
export const stringToRow = (track: Track, str: number) => track.staves[0].tuning.length - str;

export function beatAt(score: Score, r: BeatRef): Beat | null {
  const tr = score.tracks[r.t];
  const bar = tr?.staves[0]?.bars[r.b];
  const voice = bar?.voices[r.v];
  return voice?.beats[r.i] ?? null;
}
export const refOf = (beat: Beat): BeatRef => ({
  t: beat.voice.bar.staff.track.index,
  b: beat.voice.bar.index,
  v: beat.voice.index,
  i: beat.index,
});
function findNote(beat: Beat, k: NoteKey): Note | null {
  if (k.str != null) return beat.notes.find((n) => n.string === k.str) ?? null;
  if (k.art != null) return beat.notes.find((n) => n.percussionArticulation === k.art) ?? null;
  if (k.pitch != null) return beat.notes.find((n) => n.realValue === k.pitch) ?? null;
  return null;
}
function newRestBeat(dur: number, dots = 0): Beat {
  const b = new M.Beat();
  b.duration = dur as at.model.Duration;
  b.dots = dots;
  b.isEmpty = false;
  return b;
}
function relinkBeats(voice: at.model.Voice) {
  const beats = voice.beats.slice();
  voice.beats.length = 0;
  for (const b of beats) {
    b.previousBeat = null;
    b.nextBeat = null;
    voice.addBeat(b);
  }
}
function setPitchOnNote(n: Note, midi: number) {
  n.octave = Math.floor(midi / 12) - 1;
  n.tone = midi % 12;
}

// ---------- creación ----------
function trackTex(p: Preset, name: string, tuning: number[] | undefined, bars: number) {
  const rest = Array.from({ length: bars }, () => "r.1").join(" | ");
  if (p.kind === "drums") {
    const chord = `(${(p.kit ?? [38, 36, 42]).join(" ")}).1`;
    const restB = bars > 1 ? " | " + Array.from({ length: bars - 1 }, () => "r.1").join(" | ") : "";
    return `\\track "${esc(name)}" \\staff {score} \\instrument percussion \\articulation defaults ${chord}${restB} |`;
  }
  if (p.kind === "tab") {
    const tun = (tuning ?? p.tuning ?? TUNINGS.std.strings).map(texPitch).join(" ");
    return `\\track "${esc(name)}" \\staff {${p.notation ? "score tabs" : "tabs"}} \\tuning ${tun} \\instrument ${p.program} ${rest} |`;
  }
  return `\\track "${esc(name)}" \\staff {score} \\instrument ${p.program} ${rest} |`;
}
/** Ajustes que alphaTex no expresa: kit, clave, transposición, notas de plantilla. */
function finishTrack(track: Track, p: Preset) {
  const st = track.staves[0];
  track.playbackInfo.program = p.program;
  if (p.kind === "drums") {
    // El primer compás traía todas las piezas para registrar las articulaciones: se vacía.
    const beat = st.bars[0].voices[0].beats[0];
    for (const n of beat.notes.slice()) beat.removeNote(n);
  }
  if (p.kind === "notation" && p.clef === "F") for (const bar of st.bars) bar.clef = M.Clef.F4;
  if (p.transpose) st.displayTranspositionPitch = -p.transpose;
  (track as unknown as { __preset?: string }).__preset = p.id;
}

export function createSong(styleId = "blank_gtr", bars = 8, title = "Sin título"): Score {
  const style = styleById(styleId) ?? styleById("blank_gtr")!;
  let tex = `\\title "${esc(title)}" \\tempo ${style.tempo} `;
  const ps: Preset[] = [];
  for (const t of style.tracks) {
    const p = presetById(t.preset)!;
    ps.push(p);
    tex += trackTex(p, t.name, t.tuning ? TUNINGS[t.tuning].strings : undefined, bars) + " ";
  }
  const score = at.importer.ScoreLoader.loadAlphaTex(tex, settings);
  score.tracks.forEach((tr, i) => finishTrack(tr, ps[i]));
  assignChannels(score);
  finishScore(score);
  return score;
}

/** Canales MIDI únicos por pista (el 9 es de la batería). */
function assignChannels(score: Score) {
  let ch = 0;
  for (const tr of score.tracks) {
    if (tr.staves[0].isPercussion) {
      tr.playbackInfo.primaryChannel = 9;
      tr.playbackInfo.secondaryChannel = 9;
      continue;
    }
    if (ch === 9) ch++;
    tr.playbackInfo.primaryChannel = ch % 16;
    ch++;
    if (ch === 9) ch++;
    tr.playbackInfo.secondaryChannel = ch % 16;
    ch++;
  }
}

function addTrack(score: Score, presetId: string, name?: string, tuning?: number[]) {
  const p = presetById(presetId) ?? PRESETS[0];
  const bars = score.masterBars.length;
  const tex = `\\title "x" ` + trackTex(p, name ?? p.name, tuning, bars);
  const tmp = at.importer.ScoreLoader.loadAlphaTex(tex, settings);
  const tr = tmp.tracks[0];
  finishTrack(tr, p);
  // Trasplantar la pista al score actual (sus compases ya coinciden en número).
  tr.score = score;
  score.addTrack(tr);
  assignChannels(score);
}

// ---------- compases ----------
function rebuildBars(score: Score, masterBars: at.model.MasterBar[], perStaff: Map<at.model.Staff, at.model.Bar[]>) {
  score.masterBars.length = 0;
  for (const mb of masterBars) {
    mb.previousMasterBar = null;
    mb.nextMasterBar = null;
    score.addMasterBar(mb);
  }
  for (const [staff, bars] of perStaff) {
    staff.bars.length = 0;
    for (const b of bars) {
      b.previousBar = null;
      b.nextBar = null;
      staff.addBar(b);
    }
  }
}
function insertBar(score: Score, atIndex: number) {
  const idx = Math.max(0, Math.min(atIndex, score.masterBars.length));
  const ref = score.masterBars[Math.max(0, idx - 1)];
  const mb = new M.MasterBar();
  if (ref) {
    mb.timeSignatureNumerator = ref.timeSignatureNumerator;
    mb.timeSignatureDenominator = ref.timeSignatureDenominator;
    mb.tripletFeel = ref.tripletFeel;
  }
  const mbs = score.masterBars.slice();
  mbs.splice(idx, 0, mb);
  const per = new Map<at.model.Staff, at.model.Bar[]>();
  for (const tr of score.tracks)
    for (const st of tr.staves) {
      const prev = st.bars[Math.max(0, idx - 1)];
      const bar = new M.Bar();
      if (prev) {
        bar.clef = prev.clef;
        bar.keySignature = prev.keySignature;
        bar.keySignatureType = prev.keySignatureType;
      }
      const v = new M.Voice();
      bar.addVoice(v);
      v.addBeat(newRestBeat(M.Duration.Whole));
      const list = st.bars.slice();
      list.splice(idx, 0, bar);
      per.set(st, list);
    }
  rebuildBars(score, mbs, per);
}
function deleteBar(score: Score, atIndex: number) {
  if (score.masterBars.length <= 1 || atIndex < 0 || atIndex >= score.masterBars.length) return;
  const mbs = score.masterBars.slice();
  const removed = mbs.splice(atIndex, 1)[0];
  // Si el compás borrado tenía el tempo inicial, se conserva en el siguiente.
  if (atIndex === 0 && removed.tempoAutomations.length && mbs[0] && !mbs[0].tempoAutomations.length)
    mbs[0].tempoAutomations.push(...removed.tempoAutomations);
  const per = new Map<at.model.Staff, at.model.Bar[]>();
  for (const tr of score.tracks)
    for (const st of tr.staves) {
      const list = st.bars.slice();
      list.splice(atIndex, 1);
      per.set(st, list);
    }
  rebuildBars(score, mbs, per);
}
function setTempo(score: Score, b: number, bpm: number) {
  const mb = score.masterBars[b];
  if (!mb) return;
  mb.tempoAutomations = mb.tempoAutomations.filter((a) => a.type !== M.AutomationType.Tempo);
  const a = M.Automation.buildTempoAutomation(false, 0, bpm, 2);
  mb.tempoAutomations.push(a);
}

// ---------- aplicar operaciones ----------
const DYN = [M.DynamicValue.PPP, M.DynamicValue.PP, M.DynamicValue.P, M.DynamicValue.MP, M.DynamicValue.MF, M.DynamicValue.F, M.DynamicValue.FF, M.DynamicValue.FFF];
export const DYN_NAMES = ["ppp", "pp", "p", "mp", "mf", "f", "ff", "fff"];
export const dynIndex = (v: number) => Math.max(0, DYN.indexOf(v as at.model.DynamicValue));
export const dynValue = (i: number) => DYN[Math.max(0, Math.min(7, i))];

function applyNoteFx(n: Note, fx: NoteFx, on: boolean) {
  switch (fx) {
    case "hammer": n.isHammerPullOrigin = on; break;
    case "slide": n.slideOutType = on ? M.SlideOutType.Legato : M.SlideOutType.None; break;
    case "bend":
      n.bendPoints = null;
      n.bendType = M.BendType.None;
      if (on) {
        n.bendType = M.BendType.Bend;
        n.addBendPoint(new M.BendPoint(0, 0));
        n.addBendPoint(new M.BendPoint(15, 4));
        n.addBendPoint(new M.BendPoint(60, 4));
      }
      break;
    case "vibrato": n.vibrato = on ? M.VibratoType.Slight : M.VibratoType.None; break;
    case "palmMute": n.isPalmMute = on; break;
    case "letRing": n.isLetRing = on; break;
    case "dead": n.isDead = on; break;
    case "ghost": n.isGhost = on; break;
    case "accent": n.accentuated = on ? M.AccentuationType.Normal : M.AccentuationType.None; break;
    case "heavyAccent": n.accentuated = on ? M.AccentuationType.Heavy : M.AccentuationType.None; break;
    case "harmonic": n.harmonicType = on ? M.HarmonicType.Natural : M.HarmonicType.None; n.harmonicValue = on ? 12 : 0; break;
    case "staccato": n.isStaccato = on; break;
    case "tie": n.isTieDestination = on; break;
  }
}
export function noteFxState(n: Note, fx: NoteFx): boolean {
  switch (fx) {
    case "hammer": return n.isHammerPullOrigin;
    case "slide": return n.slideOutType !== M.SlideOutType.None;
    case "bend": return n.hasBend;
    case "vibrato": return n.vibrato !== M.VibratoType.None;
    case "palmMute": return n.isPalmMute;
    case "letRing": return n.isLetRing;
    case "dead": return n.isDead;
    case "ghost": return n.isGhost;
    case "accent": return n.accentuated === M.AccentuationType.Normal;
    case "heavyAccent": return n.accentuated === M.AccentuationType.Heavy;
    case "harmonic": return n.harmonicType !== M.HarmonicType.None;
    case "staccato": return n.isStaccato;
    case "tie": return n.isTieDestination;
  }
}

/** Aplica una operación. Devuelve false si no se pudo (referencia inválida). */
export function applyOp(score: Score, op: Op): Score {
  switch (op.k) {
    case "load":
      return at.model.JsonConverter.jsonToScore(op.json, settings);
    case "fret": {
      const beat = beatAt(score, op);
      if (!beat) break;
      let n = beat.notes.find((x) => x.string === op.str);
      if (!n) {
        n = new M.Note();
        n.string = op.str;
        beat.addNote(n);
      }
      n.fret = Math.max(0, Math.min(36, op.fret));
      beat.isEmpty = false;
      break;
    }
    case "pitch": {
      const beat = beatAt(score, op);
      if (!beat) break;
      const ex = beat.notes.find((x) => x.realValue === op.pitch);
      if (op.on && !ex) {
        const n = new M.Note();
        setPitchOnNote(n, op.pitch);
        beat.addNote(n);
        beat.isEmpty = false;
      } else if (!op.on && ex) beat.removeNote(ex);
      break;
    }
    case "perc": {
      const beat = beatAt(score, op);
      if (!beat) break;
      const ex = beat.notes.find((x) => x.percussionArticulation === op.art);
      if (op.on && !ex) {
        const n = new M.Note();
        n.percussionArticulation = op.art;
        beat.addNote(n);
        beat.isEmpty = false;
      } else if (!op.on && ex) beat.removeNote(ex);
      break;
    }
    case "delNote": {
      const beat = beatAt(score, op);
      const n = beat && findNote(beat, op);
      if (beat && n) beat.removeNote(n);
      break;
    }
    case "clear": {
      const beat = beatAt(score, op);
      if (beat) for (const n of beat.notes.slice()) beat.removeNote(n);
      break;
    }
    case "insBeat": {
      const voice = score.tracks[op.t]?.staves[0]?.bars[op.b]?.voices[op.v];
      if (!voice) break;
      const nb = newRestBeat(op.dur, op.dots ?? 0);
      const list = voice.beats.slice();
      list.splice(op.after + 1, 0, nb);
      voice.beats.length = 0;
      for (const b of list) voice.beats.push(b);
      relinkBeats(voice);
      break;
    }
    case "delBeat": {
      const beat = beatAt(score, op);
      if (!beat) break;
      const voice = beat.voice;
      if (voice.beats.length <= 1) {
        for (const n of beat.notes.slice()) beat.removeNote(n);
        break;
      }
      voice.beats.splice(op.i, 1);
      relinkBeats(voice);
      break;
    }
    case "dur": { const b = beatAt(score, op); if (b) b.duration = op.dur as at.model.Duration; break; }
    case "dots": { const b = beatAt(score, op); if (b) b.dots = Math.max(0, Math.min(2, op.n)); break; }
    case "tuplet": {
      const b = beatAt(score, op);
      if (!b) break;
      if (op.n <= 1) { b.tupletNumerator = -1; b.tupletDenominator = -1; }
      else { b.tupletNumerator = op.n; b.tupletDenominator = op.n === 3 ? 2 : op.n === 6 ? 4 : 4; }
      break;
    }
    case "noteFx": {
      const beat = beatAt(score, op);
      const n = beat && findNote(beat, op);
      if (n) applyNoteFx(n, op.fx, op.on);
      break;
    }
    case "beatFx": {
      const b = beatAt(score, op);
      if (!b) break;
      const v = op.val;
      switch (op.fx) {
        case "dynamics": b.dynamics = dynValue(Number(v)); for (const n of b.notes) n.dynamics = b.dynamics; break;
        case "crescendo": b.crescendo = Number(v) as at.model.CrescendoType; break;
        case "tap": b.tap = !!v; break;
        case "slap": b.slap = !!v; break;
        case "pop": b.pop = !!v; break;
        case "text": b.text = v ? String(v) : null; break;
        case "chord": b.chordId = v ? String(v) : null; break;
        case "pickStroke": b.pickStroke = Number(v) as at.model.PickStroke; break;
        case "fadeIn": b.fade = v ? M.FadeType.FadeIn : M.FadeType.None; break;
        case "brush": b.brushType = Number(v) as at.model.BrushType; break;
        case "vibratoBeat": b.vibrato = v ? M.VibratoType.Wide : M.VibratoType.None; break;
      }
      break;
    }
    case "dynFrom": {
      // Cambia la dinámica desde este tiempo hasta donde seguía la dinámica anterior.
      const start = beatAt(score, op);
      if (!start) break;
      const old = start.dynamics, nv = dynValue(op.val);
      const staff = start.voice.bar.staff;
      let on = false;
      outer: for (const bar of staff.bars) {
        if (bar.index < op.b) continue;
        const v = bar.voices[op.v];
        if (!v) continue;
        for (const b of v.beats) {
          if (bar.index === op.b && b.index < op.i) continue;
          if (on && b.dynamics !== old) break outer;
          on = true;
          b.dynamics = nv;
          for (const n of b.notes) n.dynamics = nv;
        }
      }
      break;
    }
    case "barIns": insertBar(score, op.at); break;
    case "barDel": deleteBar(score, op.at); break;
    case "barProp": {
      const mb = score.masterBars[op.b];
      if (!mb) break;
      const v = op.val;
      switch (op.prop) {
        case "ts": {
          const [n, d] = String(v).split("/").map(Number);
          if (n > 0 && [1, 2, 4, 8, 16, 32].includes(d)) { mb.timeSignatureNumerator = n; mb.timeSignatureDenominator = d; }
          break;
        }
        case "repeatOpen": mb.isRepeatStart = !!v; break;
        case "repeatClose": mb.repeatCount = Number(v) || 0; break;
        case "doubleBar": mb.isDoubleBar = !!v; break;
        case "alternate": mb.alternateEndings = Number(v) || 0; break;
        case "section": {
          if (!v) mb.section = null;
          else { const s = new M.Section(); const [marker, ...rest] = String(v).split("|"); s.marker = marker; s.text = rest.join("|") || marker; mb.section = s; }
          break;
        }
        case "tempo": setTempo(score, op.b, Number(v)); break;
        case "key": for (const tr of score.tracks) for (const st of tr.staves) { const bar = st.bars[op.b]; if (bar) bar.keySignature = Number(v) as at.model.KeySignature; } break;
      }
      break;
    }
    case "trackAdd": addTrack(score, op.preset, op.name, op.tuning); break;
    case "trackDel": {
      if (score.tracks.length <= 1) break;
      score.tracks.splice(op.t, 1);
      score.tracks.forEach((t, i) => (t.index = i));
      break;
    }
    case "trackMove": {
      const [tr] = score.tracks.splice(op.t, 1);
      if (!tr) break;
      score.tracks.splice(Math.max(0, Math.min(op.to, score.tracks.length)), 0, tr);
      score.tracks.forEach((t, i) => (t.index = i));
      break;
    }
    case "trackProp": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      const st = tr.staves[0];
      const v = op.val;
      switch (op.prop) {
        case "name": tr.name = String(v).slice(0, 60); tr.shortName = tr.name.slice(0, 10); break;
        case "program": tr.playbackInfo.program = Number(v); break;
        case "tuning": if (Array.isArray(v) && v.length === st.tuning.length) st.stringTuning = new M.Tuning("", (v as number[]).slice(), false); break;
        case "capo": st.capo = Math.max(0, Math.min(12, Number(v))); break;
        case "volume": tr.playbackInfo.volume = Math.max(0, Math.min(16, Number(v))); break;
        case "balance": tr.playbackInfo.balance = Math.max(0, Math.min(16, Number(v))); break;
        case "showTab": if (st.isStringed) st.showTablature = !!v; if (!st.showTablature && !st.showStandardNotation) st.showStandardNotation = true; break;
        case "showNotation": st.showStandardNotation = !!v; if (!st.showTablature && !st.showStandardNotation) st.showTablature = st.isStringed; break;
        case "color": break;
        case "mute": tr.playbackInfo.isMute = !!v; break;
        case "solo": tr.playbackInfo.isSolo = !!v; break;
      }
      break;
    }
    case "songProp": {
      const v = op.val;
      if (op.prop === "tempo") setTempo(score, 0, Number(v));
      else (score as unknown as Record<string, string>)[op.prop] = String(v).slice(0, 120);
      break;
    }
    case "chordDef": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      const st = tr.staves[0];
      const c = new M.Chord();
      c.name = op.name;
      // alphaTab guarda los trastes de la cuerda más aguda a la más grave.
      c.strings = op.frets.slice();
      const played = op.frets.filter((f) => f > 0);
      c.firstFret = played.length ? Math.max(1, Math.min(...played)) : 1;
      if (Math.max(0, ...played) <= 4) c.firstFret = 1;
      c.showDiagram = true;
      c.showName = true;
      st.addChord(op.id, c);
      break;
    }
    case "voices": {
      // Garantiza n voces en cada compás de la pista (las nuevas empiezan vacías).
      const tr = score.tracks[op.t];
      if (!tr) break;
      for (const bar of tr.staves[0].bars)
        while (bar.voices.length < Math.min(4, op.n)) {
          const v = new M.Voice();
          bar.addVoice(v);
          const b = new M.Beat();
          b.duration = M.Duration.Whole;
          b.isEmpty = true;
          v.addBeat(b);
        }
      break;
    }
    case "lyrics": {
      const tr = score.tracks[op.t];
      if (!tr) break;
      for (const bar of tr.staves[0].bars) for (const v of bar.voices) for (const b of v.beats) b.lyrics = null;
      const l = new M.Lyrics();
      l.startBar = 0;
      l.text = op.text;
      l.finish();
      tr.applyLyrics([l]);
      (tr as unknown as { __lyrics?: string }).__lyrics = op.text;
      break;
    }
  }
  return score;
}

/** alphaTab reinicia los ids al leer alphaTex; tras unir pistas hay que renumerarlos. */
export function renumberIds(score: Score) {
  let bar = 0, voice = 0, beat = 0, note = 0;
  for (const tr of score.tracks)
    for (const st of tr.staves)
      for (const b of st.bars) {
        b.id = bar++;
        for (const v of b.voices) {
          v.id = voice++;
          for (const bt of v.beats) {
            bt.id = beat++;
            for (const n of bt.notes) n.id = note++;
          }
        }
      }
}
export function finishScore(score: Score) {
  renumberIds(score);
  score.finish(settings);
}
export const toJson = (score: Score) => at.model.JsonConverter.scoreToJson(score);
export const fromJson = (json: string) => {
  const s = at.model.JsonConverter.jsonToScore(json, settings);
  return s;
};

// ---------- consultas de tiempo ----------
/** Duración en ticks (negra = 960) de un valor rítmico con puntillos y tresillo. */
export function beatTicks(beat: Beat): number {
  let t = 3840 / beat.duration;
  let add = t / 2;
  for (let i = 0; i < beat.dots; i++) { t += add; add /= 2; }
  if (beat.hasTuplet) t = (t * beat.tupletDenominator) / beat.tupletNumerator;
  return t;
}
export function barCapacity(mb: at.model.MasterBar) {
  return (3840 / mb.timeSignatureDenominator) * mb.timeSignatureNumerator;
}
export function voiceUsed(voice: at.model.Voice) {
  return voice.beats.reduce((s, b) => s + beatTicks(b), 0);
}
